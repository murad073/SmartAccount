﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Input;

namespace MVVMTest
{
    public class ViewModel: INotifyPropertyChanged, ICommand
    {
        public ViewModel(string nickName)
        {
            Name = nickName;
        }
        public ViewModel()
        {
            Name = "Default";
        }

        private string _name;
        public string Name { 
            get { return _name; }
            set
            {
                _name = value;
                if (PropertyChanged!=null) PropertyChanged(this, new PropertyChangedEventArgs("Name"));
            }
        }


        public ICommand ButtonClicked { get { return this; } }

        //private string _tempText;
        public string TempText { get; set; }

        public string Color { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public void Execute(object parameter)
        {
            Name = TempText;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;
    }
}
